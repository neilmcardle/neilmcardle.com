import Link from "next/link"
import Image from "next/image"
import { Star, PaintBucket, Calculator, Book } from "lucide-react"
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu"

export function TopNavigation() {
  return (
    <header className="sticky top-4 z-50 mx-auto max-w-7xl px-4">
      <nav className="flex items-center rounded-full bg-white px-6 py-4 shadow-lg">
        {/* Logo */}
        <Link href="/" className="mr-8">
          <Image src="/NMlogoBlack.svg" alt="NM Logo" width={32} height={32} priority />
        </Link>

        {/* Main Navigation */}
        <div className="flex items-center gap-8 flex-1">
          <Link href="/about" className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors">
            About Me
          </Link>

          <NavigationMenu>
            <NavigationMenuList>
              <NavigationMenuItem>
                <NavigationMenuTrigger className="text-sm font-medium text-gray-600 hover:text-gray-900">
                  Personal
                </NavigationMenuTrigger>
                <NavigationMenuContent>
                  <div className="w-[240px] p-3">
                    <Link href="/icon-creator" className="flex items-center gap-2 rounded-md p-2 hover:bg-gray-100">
                      <Star className="h-5 w-5" />
                      <span className="text-sm font-medium">Icon Creator</span>
                    </Link>
                    <Link href="/vector-paint" className="flex items-center gap-2 rounded-md p-2 hover:bg-gray-100">
                      <PaintBucket className="h-5 w-5" />
                      <span className="text-sm font-medium">Vector Paint</span>
                    </Link>
                    <Link
                      href="/home-move-calculator"
                      className="flex items-center gap-2 rounded-md p-2 hover:bg-gray-100"
                    >
                      <Calculator className="h-5 w-5" />
                      <span className="text-sm font-medium">Home Move Calculator</span>
                    </Link>
                    <Link
                      href="/property-investment-calculator"
                      className="flex items-center gap-2 rounded-md p-2 hover:bg-gray-100"
                    >
                      <Calculator className="h-5 w-5" />
                      <span className="text-sm font-medium">Property Investment Calculator</span>
                    </Link>
                    <Link href="/makeebook" className="flex items-center gap-2 rounded-md p-2 hover:bg-gray-100">
                      <Book className="h-5 w-5" />
                      <span className="text-sm font-medium">makeEbook</span>
                    </Link>
                  </div>
                </NavigationMenuContent>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>

          <Link href="/web" className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors">
            Web
          </Link>
          <Link href="/app" className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors">
            App
          </Link>
          <Link
            href="/design-systems"
            className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
          >
            Design Systems
          </Link>
        </div>

        {/* Social Links */}
        <div className="flex items-center gap-6">
          <Link
            href="https://neilmcardle.substack.com"
            className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
            target="_blank"
            rel="noopener noreferrer"
          >
            SubStack
          </Link>
          <Link
            href="https://twitter.com/neilmcardle_"
            className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
            target="_blank"
            rel="noopener noreferrer"
          >
            X
          </Link>
          <Link
            href="https://dribbble.com/neilmcardle"
            className="text-sm font-medium text-gray-600 hover:text-gray-900 transition-colors"
            target="_blank"
            rel="noopener noreferrer"
          >
            Dribbble
          </Link>
        </div>
      </nav>
    </header>
  )
}

