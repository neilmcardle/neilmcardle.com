export default function Home() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <section className="max-w-3xl mx-auto">
        <div className="space-y-6">
          <h1 className="text-4xl font-bold flex items-center gap-2">👋 Hi, I&apos;m Neil!</h1>

          <p className="text-lg text-gray-600">
            I&apos;m a designer with over 10 years of experience crafting thoughtful and engaging digital experiences.
          </p>

          <div className="space-y-4">
            <h2 className="text-xl font-semibold">
              Here on my site, you&apos;ll find some personal projects I&apos;m particularly proud of, like:
            </h2>
            <ul className="space-y-4 list-disc pl-5">
              <li>
                <strong>Icon Creator:</strong> A handy tool for designing and downloading simple SVG icons.
              </li>
              <li>
                <strong>Vector Paint:</strong> A creative drawing app I built for my daughters to spark their
                imagination. (Desktop only)
              </li>
              <li>
                <strong>Home Move Calculator:</strong> A practical tool that&apos;s helped friends and family estimate
                moving costs with ease.
              </li>
              <li>
                <strong>makeEbook:</strong> A beta version of an eBook maker to help publishers quickly create industry
                standard eBooks.
              </li>
            </ul>
          </div>

          <div className="space-y-4">
            <p>
              I also share insights from my professional work at Avis Budget Group, including contributions to an
              iconography library project and a global app design system in my in-house portfolio (password on request).
              My focus is on creating user-first designs that enhance web and mobile experiences, leveraging tools like
              Figma, HTML, CSS, and JavaScript.
            </p>

            <p>
              Previously, I worked at The Banner of Truth, where I produced over 200 eBooks, created book cover designs,
              and made my debut as a published illustrator by contributing 26 full-color illustrations for The
              Child&apos;s Story Bible.
            </p>

            <p>
              Beyond my 9-to-5, I run BetterThings, my freelance design studio where I help clients build meaningful
              visual identities. My career journey also includes early roles in digital marketing and communications,
              which sharpened my understanding of strategy and user engagement.
            </p>

            <p>
              Let&apos;s connect! Visit my{" "}
              <a href="https://www.linkedin.com/in/neilmcardle/" className="text-blue-600 hover:underline">
                LinkedIn
              </a>{" "}
              to explore how I can bring your ideas to life.
            </p>
          </div>
        </div>
      </section>
    </div>
  )
}

